# Basic app

A basic Chainlit application to get started.

![](screenshot.webp)