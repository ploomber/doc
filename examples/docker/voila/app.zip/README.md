# Custom Voila app

`app.ipynb` was taken from the [`voila-gridstack`](https://github.com/voila-dashboards/voila-gridstack/blob/main/examples/scotch_dashboard.ipynb) repository.