def hello(your_name: str) -> str:
    return f"Hello, {your_name}."
