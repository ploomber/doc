import streamlit as st


st.title("This is my streamlit app")
