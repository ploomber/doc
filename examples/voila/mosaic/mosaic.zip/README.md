# Mosaic visualisation app

This application uses Mosaic to display plots that are interactive and linked together through cross-filtering.

![](screenshot.webp)